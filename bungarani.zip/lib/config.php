<?php

$base_url ="http://localhost/Bunga_rani";
$admin_url ="http://localhost/Bunga_rani/admin/";

?>