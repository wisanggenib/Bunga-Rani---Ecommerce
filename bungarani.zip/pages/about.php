<!-- Title Page -->
	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url(asset/images/heading-pages-06.jpg);">
		<h2 class="l-text2 t-center">
			About
		</h2>
	</section>

	<!-- content page -->
	<section class="bgwhite p-t-66 p-b-38">
		<div class="container">
			<div class="row">
				<div class="col-md-4 p-b-30">
					<div class="hov-img-zoom">
						<img src="asset/images/banner-14.jpg" alt="IMG-ABOUT">
					</div>
				</div>

				<div class="col-md-8 p-b-30">
					<h3 class="m-text26 p-t-15 p-b-16">
						Tentang Kami
					</h3>

					<p class="p-b-28">
						Toko bunga rani adalah sebuah toko yang menyediakan berbagai macam jenis bunga untuk segala acara. Bermula dari sebuah bangunan yang berlokasi di Jalan raya purwomartani karanglo grenjeng,toko kami akhirnya bisa menjangkau pasar yang lebih luas lagi melalui internet.

						Seiring dengan semakin berkembangnya teknologi, maka kami mencoba berinovasi dalam berbisnis. Salah satu bentuk inovasinya adalah dengan menyediakan berbagai layanan toko kami melalui media internet, dan toko online ini adalah salah satu bentuk pelayanan kami kepada Anda.
					</p>

					<div class="bo13 p-l-29 m-l-9 p-b-10">
						<p class="p-b-11">
							Man jadda wajada. Siapa yang bersungguh-sungguh, akan berhasil.	
						</p>

						<span class="s-text7">
							- Ahmad Fuadi, Negeri 5 Menara
						</span>
					</div>
				</div>
			</div>
		</div>
	</section>
