<?php
echo $_POST['num-product'];

?>